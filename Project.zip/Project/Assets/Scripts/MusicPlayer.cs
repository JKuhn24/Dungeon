﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MusicPlayer : MonoBehaviour
{
    bool toggle = true;
    private void Awake()
    {
        int numMusicPlayers = FindObjectsOfType<MusicPlayer>().Length;
        if (numMusicPlayers > 1)
        {
            Destroy(gameObject);
        }
        else
        {
            DontDestroyOnLoad(gameObject);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        DontDestroyOnLoad(gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void deleteObject()
    {
        Destroy(gameObject);
    }

    public void DontDelete()
    {
        DontDestroyOnLoad(gameObject);
    }

    public void Toggle()
    {
        if (toggle)
        {
            gameObject.SetActive(false);
            toggle = false;
        }
        else
        {
            gameObject.SetActive(true);
            toggle = true;
        }
        print("toggle");
    }
}
