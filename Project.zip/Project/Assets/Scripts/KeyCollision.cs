﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyCollision : MonoBehaviour
{
    KeyThings key;
    [SerializeField] AudioClip pickup;
    AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        key = FindObjectOfType<KeyThings>();
        audioSource = GetComponent<AudioSource>();
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter(Collision collision)
    {
        key.AddKey();
        audioSource.PlayOneShot(pickup);
        Invoke("KeyGone", 0.2f);
        print("Hit");
    }

    private void KeyGone()
    {
        Destroy(gameObject);
    }
}
